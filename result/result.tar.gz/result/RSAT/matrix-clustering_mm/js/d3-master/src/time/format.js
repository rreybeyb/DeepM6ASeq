import "../locale/en-US";
import "time";

var d3_time_format = d3_time.format = d3_locale_enUS.timeFormat;
